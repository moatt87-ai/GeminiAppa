package com.gemini.arabicassistant.ui.settings

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class InstalledAppItem(
    val label: String,
    val packageName: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    initialAssistantName: String,
    initialDimAlpha: Float,
    installedApps: List<InstalledAppItem>,
    initialBlacklisted: Set<String>,
    onSaveAssistantName: (String) -> Unit,
    onSaveWallpaperUri: (String?) -> Unit,
    onSaveDimAlpha: (Float) -> Unit,
    onSaveBlacklist: (Set<String>) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var assistantName by remember { mutableStateOf(initialAssistantName) }
    var dimAlpha by remember { mutableFloatStateOf(initialDimAlpha) }
    var blacklisted by remember { mutableStateOf(initialBlacklisted) }

    val galleryPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            onSaveWallpaperUri(uri.toString())
        }
    }

    Scaffold(
        containerColor = Color(0xFF131314),
        topBar = {
            TopAppBar(
                title = { Text("الإعدادات والتخصيص", color = Color(0xFFE3E3E3)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "رجوع",
                            tint = Color(0xFFE3E3E3)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF131314))
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text("هوية المساعد", color = Color(0xFFA8C7FA), fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = assistantName,
                    onValueChange = {
                        assistantName = it
                        onSaveAssistantName(it)
                    },
                    label = { Text("الاسم المخصص للمساعد") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                Text("خلفية المحادثة من المعرض", color = Color(0xFFA8C7FA), fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            galleryPicker.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Rounded.Image, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("اختيار صورة من المعرض")
                    }
                    OutlinedButton(
                        onClick = { onSaveWallpaperUri(null) },
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("إزالة الخلفية")
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    text = "درجة تعتيم الخلفية لوضوح النص: ${(dimAlpha * 100).toInt()}%",
                    color = Color(0xFFC4C7C5),
                    fontSize = 13.sp
                )
                Slider(
                    value = dimAlpha,
                    onValueChange = {
                        dimAlpha = it
                        onSaveDimAlpha(it)
                    },
                    valueRange = 0f..0.9f
                )
            }

            item {
                Text(
                    text = "القائمة السوداء للتطبيقات (يُمنع المساعد من فتحها)",
                    color = Color(0xFFA8C7FA),
                    fontWeight = FontWeight.SemiBold
                )
            }

            items(installedApps, key = { it.packageName }) { app ->
                val isBlocked = blacklisted.contains(app.packageName)
                Surface(
                    color = Color(0xFF1E1F20),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(app.label, color = Color(0xFFE3E3E3), fontWeight = FontWeight.Medium)
                            Text(app.packageName, color = Color(0xFF8E918F), fontSize = 12.sp)
                        }
                        Switch(
                            checked = isBlocked,
                            onCheckedChange = { checked ->
                                blacklisted = if (checked) {
                                    blacklisted + app.packageName
                                } else {
                                    blacklisted - app.packageName
                                }
                                onSaveBlacklist(blacklisted)
                            }
                        )
                    }
                }
            }
        }
    }
}
