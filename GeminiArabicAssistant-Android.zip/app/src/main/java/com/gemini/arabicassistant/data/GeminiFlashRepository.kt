package com.gemini.arabicassistant.data

import com.gemini.arabicassistant.actions.DeviceActionExecutor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class GeminiResult(
    val replyText: String,
    val executedActionSummary: String? = null
)

class GeminiFlashRepository(
    private val prefs: SecurePrefsManager,
    private val actionExecutor: DeviceActionExecutor
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val modelName = "gemini-2.5-flash"

    suspend fun validateApiKey(apiKey: String): Boolean = withContext(Dispatchers.IO) {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"
        val body = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", "ping")))
            }))
            put("generationConfig", JSONObject().put("maxOutputTokens", 4))
        }
        val req = Request.Builder()
            .url(url)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        runCatching {
            client.newCall(req).execute().use { it.isSuccessful }
        }.getOrDefault(false)
    }

    suspend fun sendMessage(
        userText: String,
        lowBandwidthVoiceMode: Boolean = false
    ): GeminiResult = withContext(Dispatchers.IO) {
        val apiKey = prefs.getGeminiApiKey()
            ?: return@withContext GeminiResult("مفتاح API غير متوفر.")

        val assistantName = prefs.getAssistantName()
        val blacklisted = prefs.getBlacklistedPackages().joinToString(", ")

        val systemInstruction = """
            أنت "$assistantName"، مساعد أندرويد شخصي باللغة العربية.
            القائمة السوداء للحزم المحظورة: [$blacklisted].
            يُمنع منعاً باتاً فتح أي تطبيق مدرج في القائمة السوداء.
            ${if (lowBandwidthVoiceMode) "اجعل ردك مختصراً جداً (جملة أو جملتان) ومناسباً للنطق الصوتي السريع." else ""}
        """.trimIndent()

        val tools = buildFunctionDeclarations()
        val contents = JSONArray().put(JSONObject().apply {
            put("role", "user")
            put("parts", JSONArray().put(JSONObject().put("text", userText)))
        })

        val firstJson = executeWithRetry(apiKey, systemInstruction, contents, tools, lowBandwidthVoiceMode)
            ?: return@withContext GeminiResult("تعذر الاتصال بالإنترنت. يرجى المحاولة بعد قليل.")

        val candidate = firstJson.optJSONArray("candidates")?.optJSONObject(0)
        val contentObj = candidate?.optJSONObject("content")
        val parts = contentObj?.optJSONArray("parts") ?: JSONArray()

        var functionCallPart: JSONObject? = null
        for (i in 0 until parts.length()) {
            val part = parts.optJSONObject(i)
            if (part?.has("functionCall") == true) {
                functionCallPart = part.optJSONObject("functionCall")
                break
            }
        }

        if (functionCallPart != null) {
            val fnName = functionCallPart.optString("name")
            val args = functionCallPart.optJSONObject("args") ?: JSONObject()
            val executionResult = actionExecutor.executeFunction(fnName, args)

            // Send function response back to Gemini Flash for natural Arabic confirmation
            contents.put(contentObj)
            contents.put(JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().apply {
                    put("functionResponse", JSONObject().apply {
                        put("name", fnName)
                        put("response", executionResult.toJson())
                    })
                }))
            })

            val followUp = executeWithRetry(apiKey, systemInstruction, contents, tools, lowBandwidthVoiceMode)
            val finalReply = extractText(followUp) ?: executionResult.userMessageAr
            return@withContext GeminiResult(finalReply, executionResult.userMessageAr)
        }

        val reply = extractText(firstJson) ?: "لم أفهم الطلب، هل يمكنك التوضيح؟"
        GeminiResult(reply)
    }

    private suspend fun executeWithRetry(
        apiKey: String,
        systemInstruction: String,
        contents: JSONArray,
        tools: JSONArray,
        lowBandwidth: Boolean
    ): JSONObject? {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"
        val payload = JSONObject().apply {
            put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemInstruction))))
            put("contents", contents)
            put("tools", tools)
            put("generationConfig", JSONObject().apply {
                put("maxOutputTokens", if (lowBandwidth) 140 else 1024)
            })
        }

        var attempt = 0
        var backoffMs = 500L
        while (attempt < 3) {
            val request = Request.Builder()
                .url(url)
                .header("Accept-Encoding", "gzip")
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()
            try {
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val raw = response.body?.string() ?: return null
                        return JSONObject(raw)
                    }
                }
            } catch (_: Exception) {
                // Retry with exponential backoff on intermittent network drops
            }
            attempt++
            delay(backoffMs)
            backoffMs *= 2
        }
        return null
    }

    private fun extractText(json: JSONObject?): String? {
        val parts = json?.optJSONArray("candidates")
            ?.optJSONObject(0)
            ?.optJSONObject("content")
            ?.optJSONArray("parts") ?: return null
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val text = parts.optJSONObject(i)?.optString("text")
            if (!text.isNullOrBlank()) sb.append(text)
        }
        return sb.toString().ifBlank { null }
    }

    private fun buildFunctionDeclarations(): JSONArray {
        val openApp = JSONObject().apply {
            put("name", "open_installed_app")
            put("description", "Open an installed app on Android while respecting the Blacklist.")
            put("parameters", JSONObject().apply {
                put("type", "OBJECT")
                put("properties", JSONObject().apply {
                    put("appName", JSONObject().put("type", "STRING"))
                    put("packageName", JSONObject().put("type", "STRING"))
                })
                put("required", JSONArray().put("appName"))
            })
        }
        val createContact = JSONObject().apply {
            put("name", "create_contact")
            put("description", "Save a new contact in Android ContactsContract.")
            put("parameters", JSONObject().apply {
                put("type", "OBJECT")
                put("properties", JSONObject().apply {
                    put("fullName", JSONObject().put("type", "STRING"))
                    put("phoneNumber", JSONObject().put("type", "STRING"))
                })
                put("required", JSONArray().put("fullName").put("phoneNumber"))
            })
        }
        val sendWhatsApp = JSONObject().apply {
            put("name", "prepare_whatsapp_message")
            put("description", "Prepare or send a WhatsApp message via Android Intent.")
            put("parameters", JSONObject().apply {
                put("type", "OBJECT")
                put("properties", JSONObject().apply {
                    put("recipientName", JSONObject().put("type", "STRING"))
                    put("phoneNumber", JSONObject().put("type", "STRING"))
                    put("messageText", JSONObject().put("type", "STRING"))
                })
                put("required", JSONArray().put("recipientName").put("messageText"))
            })
        }
        return JSONArray().put(
            JSONObject().put(
                "functionDeclarations",
                JSONArray().put(openApp).put(createContact).put(sendWhatsApp)
            )
        )
    }
}
