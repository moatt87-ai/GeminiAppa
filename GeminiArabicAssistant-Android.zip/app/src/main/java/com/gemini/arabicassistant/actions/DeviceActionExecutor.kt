package com.gemini.arabicassistant.actions

import android.content.ContentProviderOperation
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import com.gemini.arabicassistant.data.SecurePrefsManager
import org.json.JSONObject
import java.net.URLEncoder

data class ActionExecutionResult(
    val status: String,
    val userMessageAr: String
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("status", status)
        put("message", userMessageAr)
    }
}

class DeviceActionExecutor(
    private val context: Context,
    private val prefs: SecurePrefsManager
) {
    fun executeFunction(name: String, args: JSONObject): ActionExecutionResult {
        return when (name) {
            "open_installed_app" -> openApp(
                appName = args.optString("appName"),
                packageName = args.optString("packageName").takeIf { it.isNotBlank() }
            )
            "create_contact" -> createContact(
                fullName = args.optString("fullName"),
                phoneNumber = args.optString("phoneNumber")
            )
            "prepare_whatsapp_message" -> prepareWhatsApp(
                recipientName = args.optString("recipientName"),
                phoneNumber = args.optString("phoneNumber"),
                messageText = args.optString("messageText")
            )
            else -> ActionExecutionResult("error", "إجراء غير مدعوم.")
        }
    }

    private fun openApp(appName: String, packageName: String?): ActionExecutionResult {
        val pm = context.packageManager
        val installed = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val targetApp = installed.firstOrNull { appInfo ->
            val label = pm.getApplicationLabel(appInfo).toString()
            (packageName != null && appInfo.packageName.equals(packageName, ignoreCase = true)) ||
                label.contains(appName, ignoreCase = true) ||
                appInfo.packageName.contains(appName, ignoreCase = true)
        } ?: return ActionExecutionResult("not_found", "لم يتم العثور على التطبيق '$appName' على جهازك.")

        val blacklisted = prefs.getBlacklistedPackages()
        if (blacklisted.contains(targetApp.packageName)) {
            return ActionExecutionResult(
                status = "blocked_by_blacklist",
                userMessageAr = "تم حظر فتح تطبيق '$appName' لأنه مدرج في القائمة السوداء في الإعدادات."
            )
        }

        val launchIntent = pm.getLaunchIntentForPackage(targetApp.packageName)
            ?: return ActionExecutionResult("no_launcher", "التطبيق '$appName' لا يحتوي على واجهة تشغيل.")

        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launchIntent)
        return ActionExecutionResult("executed", "تم فتح تطبيق $appName بنجاح.")
    }

    private fun createContact(fullName: String, phoneNumber: String): ActionExecutionResult {
        return try {
            val ops = ArrayList<ContentProviderOperation>().apply {
                add(
                    ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                        .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                        .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                        .build()
                )
                add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, fullName)
                        .build()
                )
                add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, phoneNumber)
                        .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
                        .build()
                )
            }
            context.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
            ActionExecutionResult("executed", "تمت إضافة جهة الاتصال '$fullName' ($phoneNumber).")
        } catch (e: Exception) {
            ActionExecutionResult("error", "تعذر حفظ جهة الاتصال: ${e.localizedMessage}")
        }
    }

    private fun prepareWhatsApp(
        recipientName: String,
        phoneNumber: String,
        messageText: String
    ): ActionExecutionResult {
        val blacklisted = prefs.getBlacklistedPackages()
        if (blacklisted.contains("com.whatsapp") || blacklisted.contains("com.whatsapp.w4b")) {
            return ActionExecutionResult(
                status = "blocked_by_blacklist",
                userMessageAr = "تم منع تجهيز رسالة واتساب لأن تطبيق واتساب محظور في القائمة السوداء."
            )
        }

        val cleanDigits = phoneNumber.filter { it.isDigit() }
        val encodedMsg = URLEncoder.encode(messageText, "UTF-8")
        val uri = if (cleanDigits.isNotEmpty()) {
            Uri.parse("https://wa.me/$cleanDigits?text=$encodedMsg")
        } else {
            Uri.parse("whatsapp://send?text=$encodedMsg")
        }

        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage("com.whatsapp")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        return try {
            context.startActivity(intent)
            ActionExecutionResult("executed", "تم فتح واتساب وتجهيز الرسالة إلى $recipientName.")
        } catch (_: Exception) {
            ActionExecutionResult("error", "تطبيق واتساب غير مثبت على هذا الجهاز.")
        }
    }
}
