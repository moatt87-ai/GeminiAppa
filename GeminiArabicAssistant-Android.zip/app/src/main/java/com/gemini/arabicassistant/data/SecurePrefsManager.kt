package com.gemini.arabicassistant.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class SecurePrefsManager(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "gemini_assistant_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveGoogleUser(name: String, email: String) {
        prefs.edit()
            .putBoolean(KEY_IS_SIGNED_IN, true)
            .putString(KEY_USER_NAME, name)
            .putString(KEY_USER_EMAIL, email)
            .apply()
    }

    fun isSignedIn(): Boolean = prefs.getBoolean(KEY_IS_SIGNED_IN, false)
    fun getUserName(): String = prefs.getString(KEY_USER_NAME, "المستخدم") ?: "المستخدم"
    fun getUserEmail(): String = prefs.getString(KEY_USER_EMAIL, "") ?: ""

    fun saveGeminiApiKey(apiKey: String) {
        prefs.edit().putString(KEY_GEMINI_API_KEY, apiKey.trim()).apply()
    }

    fun getGeminiApiKey(): String? = prefs.getString(KEY_GEMINI_API_KEY, null)
    fun hasValidApiKey(): Boolean = !getGeminiApiKey().isNullOrBlank()

    fun saveAssistantName(name: String) {
        prefs.edit().putString(KEY_ASSISTANT_NAME, name.ifBlank { "جيميناي" }).apply()
    }

    fun getAssistantName(): String =
        prefs.getString(KEY_ASSISTANT_NAME, "جيميناي") ?: "جيميناي"

    fun saveWallpaperUri(uri: String?) {
        prefs.edit().putString(KEY_WALLPAPER_URI, uri).apply()
    }

    fun getWallpaperUri(): String? = prefs.getString(KEY_WALLPAPER_URI, null)

    fun saveWallpaperDimming(alpha: Float) {
        prefs.edit().putFloat(KEY_WALLPAPER_DIM, alpha.coerceIn(0f, 0.92f)).apply()
    }

    fun getWallpaperDimming(): Float = prefs.getFloat(KEY_WALLPAPER_DIM, 0.55f)

    fun saveBlacklistedPackages(packages: Set<String>) {
        prefs.edit().putStringSet(KEY_BLACKLISTED_PACKAGES, packages).apply()
    }

    fun getBlacklistedPackages(): Set<String> =
        prefs.getStringSet(KEY_BLACKLISTED_PACKAGES, emptySet()) ?: emptySet()

    fun clearSession() {
        prefs.edit().clear().apply()
    }

    companion object {
        private const val KEY_IS_SIGNED_IN = "is_signed_in"
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_USER_EMAIL = "user_email"
        private const val KEY_GEMINI_API_KEY = "gemini_api_key"
        private const val KEY_ASSISTANT_NAME = "assistant_name"
        private const val KEY_WALLPAPER_URI = "wallpaper_uri"
        private const val KEY_WALLPAPER_DIM = "wallpaper_dim"
        private const val KEY_BLACKLISTED_PACKAGES = "blacklisted_packages"
    }
}
