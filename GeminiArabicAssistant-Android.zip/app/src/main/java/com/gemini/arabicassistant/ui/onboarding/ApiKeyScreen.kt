package com.gemini.arabicassistant.ui.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gemini.arabicassistant.data.GeminiFlashRepository
import kotlinx.coroutines.launch

@Composable
fun ApiKeyScreen(
    userName: String,
    repository: GeminiFlashRepository,
    onKeyValidated: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    var apiKeyInput by remember { mutableStateOf("") }
    var isValidating by remember { mutableStateOf(false) }
    var validationError by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF131314))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.Key,
                contentDescription = null,
                tint = Color(0xFFA8C7FA),
                modifier = Modifier.size(48.dp)
            )

            Text(
                text = "أهلاً $userName، أضف مفتاح Gemini API",
                color = Color(0xFFE3E3E3),
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            Text(
                text = "يرجى لصق مفتاح Gemini API الشخصي الخاص بك. سيتم التحقق من صحته وحفظه بتشفير AES-256 داخل جهازك عبر EncryptedSharedPreferences.",
                color = Color(0xFFC4C7C5),
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                lineHeight = 22.sp
            )

            OutlinedTextField(
                value = apiKeyInput,
                onValueChange = {
                    apiKeyInput = it
                    validationError = null
                },
                label = { Text("مفتاح Gemini API") },
                placeholder = { Text("AIzaSy...") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            )

            validationError?.let { err ->
                Text(
                    text = err,
                    color = Color(0xFFFFB4AB),
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )
            }

            Button(
                onClick = {
                    val trimmed = apiKeyInput.trim()
                    if (trimmed.length < 20) {
                        validationError = "صيغة المفتاح غير صالحة."
                        return@Button
                    }
                    isValidating = true
                    validationError = null
                    scope.launch {
                        val isValid = repository.validateApiKey(trimmed)
                        isValidating = false
                        if (isValid) {
                            onKeyValidated(trimmed)
                        } else {
                            validationError = "تعذر التحقق من المفتاح. تأكد من اتصالك وصلاحية المفتاح."
                        }
                    }
                },
                enabled = !isValidating && apiKeyInput.isNotBlank(),
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFA8C7FA),
                    contentColor = Color(0xFF062E6F)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                if (isValidating) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                } else {
                    Icon(Icons.Rounded.VerifiedUser, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("التحقق وحفظ المفتاح", fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
