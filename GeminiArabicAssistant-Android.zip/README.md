# رفيق جيميناي — مساعد أندرويد الشخصي (Kotlin + Jetpack Compose)

## المزايا المدمجة
1. شاشة تسجيل دخول Google الإلزامية عبر Credential Manager.
2. شاشة التحقق من مفتاح Gemini API وحفظه في EncryptedSharedPreferences.
3. واجهة محادثة عربية RTL مطابقة لتطبيق Gemini مع خلفية المعرض وشريط التعتيم.
4. تنفيذ أوامر الجهاز عبر Gemini Function Calling مع فرض القائمة السوداء.
5. خدمة الفقاعة العائمة SYSTEM_ALERT_WINDOW مع SpeechRecognizer و TextToSpeech.
